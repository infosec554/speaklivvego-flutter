abstract class BaseExtraModel {
  const BaseExtraModel();

  Map<String, dynamic> toJson();

  String get getClassName;
}
